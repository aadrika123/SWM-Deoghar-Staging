System.register([],(function(e,t){"use strict";return{execute:function(){e("g",(function(e){return e instanceof Error?e.message:String(e)}))}}}));
