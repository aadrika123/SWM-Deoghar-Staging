import{j as e}from"./index-DXAP7HMK.js";function g({page:t,perPage:n,totalPage:a,setPage:o}){return e.jsx(e.Fragment,{children:null})}export{g as P};
