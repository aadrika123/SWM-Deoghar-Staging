System.register(["./router-legacy-BWed7M0P.js"],(function(e,t){"use strict";return{setters:[null],execute:function(){}}}));
